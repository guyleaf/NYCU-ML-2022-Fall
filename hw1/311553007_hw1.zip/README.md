﻿# HW1: regularized linear model regression & visualization

## How to execute?
```bash
cd hw1
make all
./main.out
```